from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, ServiceRequest
from django.forms.widgets import DateInput, TimeInput

class RegisterForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2', 'full_name', 'phone', 'email']

class ServiceRequestForm(forms.ModelForm):
    class Meta:
        model = ServiceRequest
        fields = ['address', 'phone', 'date', 'time', 'service', 'other_service', 'payment_method']
        widgets = {
            'date' : DateInput(attrs= {'type' : 'date', 'class': 'form-control'}),
            'time' : TimeInput(attrs={'type' : 'time', 'class' : 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['other_service'].widget.attrs.update({'style': 'display:none;'})