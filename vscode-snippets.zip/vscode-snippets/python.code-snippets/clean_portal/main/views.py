from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from .forms import RegisterForm, ServiceRequestForm
from .models import ServiceRequest
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required

def register_view(request):
    form = RegisterForm(request.POST or None)
    if form.is_valid():
        user = form.save()
        login(request, user)
        return redirect('dashboard')
    return render(request, 'main/register.html', {'form': form})

def login_view(request):
    form = AuthenticationForm(request, data=request.POST or None)
    if form.is_valid():
        user = form.get_user()
        login(request, user)
        return redirect('dashboard')
    return render(request, 'main/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def dashboard_view(request):
    form = ServiceRequestForm(request.POST or None)
    if form.is_valid():
        sr = form.save(commit=False)
        sr.user = request.user
        sr.save()
        return redirect('dashboard')
    services = ServiceRequest.objects.filter(user=request.user)
    return render(request, 'main/dashboard.html', {'form': form, 'services': services})
