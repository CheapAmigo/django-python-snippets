from django.contrib import admin
from django import forms
from .models import ServiceRequest

class ServiceRequestForm(forms.ModelForm):
    def clean(self):
        data = self.cleaned_data
        
        # Правило 1: Если услуга "иная" → нужно описание
        if data.get('service') == 'other' and not data.get('other_service'):
            raise forms.ValidationError({'other_service': 'Укажите описание услуги!'})
        
        # Правило 2: Если статус "отменено" → нужна причина
        if data.get('status') == 'cancelled' and not data.get('cancellation_reason'):
            raise forms.ValidationError({'cancellation_reason': 'Укажите причину отмены!'})
        
        return data

@admin.register(ServiceRequest)
class ServiceRequestAdmin(admin.ModelAdmin):
    form = ServiceRequestForm
    
    def save_model(self, request, obj, form, change):
        # Автоматическая очистка лишних данных
        obj.cancellation_reason = '' if obj.status != 'cancelled' else obj.cancellation_reason
        obj.other_service = '' if obj.service != 'other' else obj.other_service
        super().save_model(request, obj, form, change)