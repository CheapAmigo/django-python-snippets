from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator

class User(AbstractUser):
    full_name = models.CharField(max_length=100, validators=[RegexValidator(regex='^[А-Яа-яЁё\s]+$', message= "ФИО должно содержать только кириллицу и пробелы.")])
    phone = models.CharField(max_length=12, validators=[RegexValidator(regex= r'^\+7\d{10}$', message= "Формат +7 - XXX - XXX - XX - XX")])
    email = models.EmailField(unique=True)

class ServiceRequest(models.Model):
    SERVICE_CHOICES = [
        ('general', 'Общий клининг'),
        ('deep', 'Генеральная уборка'),
        ('post', 'Послестроительная уборка'),
        ('chem', 'Химчистка ковров и мебели'),
        ('other', 'Иная услуга'),
    ]

    STATUS_CHOICES = [
        ('new', 'Новая'),
        ('in_progress', 'В работе'),
        ('done', 'Выполнено'),
        ('cancelled', 'Отменено'),
    ]

    PAYMENT_CHOICES = [
        ('cash', 'Наличные'),
        ('card', 'Банковская карта'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    address = models.CharField(max_length= 255)
    phone = models.CharField(max_length=12, validators=[RegexValidator(regex= r'^\+7\d{10}$', message= "Формат +7 - XXX - XXX - XX - XX")])
    date = models.DateField()
    time = models.TimeField()
    service = models.CharField(max_length= 255, choices= SERVICE_CHOICES)
    other_service = models.CharField(max_length= 255, blank=True, null=True)
    status = models.CharField(max_length=255, choices= STATUS_CHOICES, default='new')
    payment_method = models.CharField(max_length= 255, choices= PAYMENT_CHOICES)
    cancellation_reason = models.CharField(max_length= 255, blank=True, null=True)