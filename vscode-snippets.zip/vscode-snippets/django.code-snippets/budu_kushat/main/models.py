from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import RegexValidator, MinValueValidator, MaxValueValidator

class User(AbstractUser):
    full_name = models.CharField(
        max_length=100, 
        validators=[
            RegexValidator(
                regex='^[А-Яа-яЁё\s]+$', 
                message="ФИО должно содержать только кириллицу и пробелы."
            )
        ],
        verbose_name='ФИО'
    )
    phone = models.CharField(
        max_length=12, 
        validators=[
            RegexValidator(
                regex=r'^\+7\d{10}$', 
                message="Формат +7XXXXXXXXXX"
            )
        ],
        verbose_name='Телефон'
    )
    email = models.EmailField(unique=True, verbose_name='Email')
    
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='Группы, к которым принадлежит этот пользователь. Пользователь получит все разрешения, предоставленные для каждой из своих групп.',
        related_name="main_user_groups",
        related_query_name="main_user",
    )
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Особые разрешения для этого пользователя.',
        related_name="main_user_permissions",
        related_query_name="main_user",
    )

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'

class Reservation(models.Model):
    STATUS_CHOICES = [
        ('new', 'Новое'),
        ('completed', 'Посещение состоялось'),
        ('canceled', 'Отменено'),
    ]
    
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name='Пользователь')
    date = models.DateField(verbose_name='Дата')
    time = models.TimeField(verbose_name='Время')
    guests = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(10)],
        verbose_name='Количество гостей'
    )
    phone = models.CharField(max_length=12, validators=[ RegexValidator( regex=r'^\+7\d{10}$', message="Формат +7XXXXXXXXXX" ) ], verbose_name='Контактный телефон')
    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default='new',
        verbose_name='Статус'
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата создания')
    
    def delete(self, *args, **kwargs):
        # Удаляем связанный отзыв перед удалением бронирования
        if hasattr(self, 'review'):
            self.review.delete()
        super().delete(*args, **kwargs)

    class Meta:
        verbose_name = 'Бронирование'
        verbose_name_plural = 'Бронирования'
        ordering = ['-created_at']

class Review(models.Model):
    reservation = models.OneToOneField(
        Reservation,
        on_delete=models.CASCADE,
        verbose_name='Бронирование',
        related_name='review'
    )
    text = models.TextField(verbose_name='Текст отзыва')
    rating = models.PositiveIntegerField(
        validators=[MinValueValidator(1), MaxValueValidator(5)],
        verbose_name='Оценка'
    )
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='Дата создания')
    
    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'