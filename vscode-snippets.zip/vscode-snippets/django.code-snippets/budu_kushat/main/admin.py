from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, Reservation, Review

class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'full_name', 'phone', 'is_staff')
    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Персональная информация', {'fields': ('full_name', 'phone', 'email')}),
        ('Права', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Важные даты', {'fields': ('last_login', 'date_joined')}),
    )

class ReviewInline(admin.StackedInline):
    model = Review
    extra = 0  # Не показывать дополнительные пустые формы
    can_delete = True
    fields = ('rating', 'text', 'created_at')
    readonly_fields = ('created_at',)

@admin.register(Reservation)
class ReservationAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'date', 'time', 'guests', 'status', 'created_at')
    list_editable = ('status',)
    list_filter = ('status', 'date')
    search_fields = ('user__username', 'user__full_name', 'phone')
    inlines = [ReviewInline]
    
    def save_model(self, request, obj, form, change):
        # Если статус меняется на "Отменено", удаляем связанный отзыв
        if 'status' in form.changed_data and obj.status == 'canceled':
            if hasattr(obj, 'review'):
                obj.review.delete()
        super().save_model(request, obj, form, change)

@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ('reservation', 'rating', 'short_text', 'created_at')
    list_filter = ('rating',)
    search_fields = ('reservation__user__username', 'reservation__user__full_name')
    
    def short_text(self, obj):
        return f"{obj.text[:50]}..." if len(obj.text) > 50 else obj.text
    short_text.short_description = 'Текст отзыва'

# Регистрируем кастомную модель User
admin.site.register(User, CustomUserAdmin)