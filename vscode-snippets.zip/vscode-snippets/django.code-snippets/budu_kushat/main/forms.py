from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.core.validators import RegexValidator
from .models import User, Reservation, Review
from django.core.exceptions import ValidationError
from datetime import date, time
import re

class RegisterForm(UserCreationForm):
    username = forms.CharField(
        label='Логин',
        min_length=6,
        validators=[
            RegexValidator(
                regex='^[А-Яа-яЁё0-9]+$',
                message='Логин должен содержать только кириллицу и цифры'
            )
        ],
        help_text='Минимум 6 символов (только кириллица и цифры)',
        widget=forms.TextInput(attrs={'pattern': '[А-Яа-яЁё0-9]{6,}'})
    )
    
    def clean_username(self):
        username = self.cleaned_data['username']
        # Проверка на минимум 6 символов кириллицы
        if len(re.sub(r'[^А-Яа-яЁё]', '', username)) < 6:
            raise ValidationError("Логин должен содержать минимум 6 букв кириллицы")
        return username
    
    class Meta:
        model = User
        fields = ['username', 'password1', 'password2', 'full_name', 'phone', 'email']
        labels = {
            'full_name': 'ФИО',
            'phone': 'Телефон',
            'email': 'Email',
        }
        widgets = {
            'full_name': forms.TextInput(attrs={'placeholder': 'Иванов Иван Иванович'}),
            'phone': forms.TextInput(attrs={'placeholder': '+79991234567'}),
        }

class LoginForm(AuthenticationForm):
    username = forms.CharField(label='Логин')
    password = forms.CharField(label='Пароль', widget=forms.PasswordInput)

class ReservationForm(forms.ModelForm):
    class Meta:
        model = Reservation
        fields = ['date', 'time', 'guests', 'phone']
        widgets = {
            'date': forms.DateInput(attrs={'type': 'date'}),
            'time': forms.TimeInput(attrs={'type': 'time'}),
        }
        labels = {
            'date': 'Дата',
            'time': 'Время',
            'guests': 'Количество гостей',
            'phone': 'Контактный телефон',
        }
    
    def clean_date(self):
        data = self.cleaned_data['date']
        if data < date.today():
            raise ValidationError("Нельзя забронировать столик на прошедшую дату")
        return data

class ReviewForm(forms.ModelForm):
    class Meta:
        model = Review
        fields = ['text', 'rating']
        labels = {
            'text': 'Текст отзыва',
            'rating': 'Оценка (1-5)',
        }
        widgets = {
            'text': forms.Textarea(attrs={'rows': 4, 'placeholder': 'Ваш отзыв о посещении...'}),
            'rating': forms.NumberInput(attrs={'min': 1, 'max': 5}),
        }