from django.shortcuts import render, redirect
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import RegisterForm, LoginForm, ReservationForm, ReviewForm
from .models import Reservation, Review

def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('profile')  # Перенаправляем на профиль
    else:
        form = RegisterForm()
    return render(request, 'main/register.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('profile')
        else:
            messages.error(request, 'Неверный логин или пароль. Пожалуйста, попробуйте снова.')
    else:
        form = LoginForm()
    return render(request, 'main/login.html', {'form': form})

def logout_view(request):
    logout(request)
    return redirect('login')

@login_required
def profile_view(request):
    reservations = Reservation.objects.filter(user=request.user).order_by('-created_at')
    return render(request, 'main/profile.html', {'reservations': reservations})

@login_required
def create_reservation(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            reservation = form.save(commit=False)
            reservation.user = request.user
            reservation.save()
            messages.success(request, 'Ваше бронирование отправлено на рассмотрение!')
            return redirect('profile')
    else:
        form = ReservationForm()
    return render(request, 'main/reservation.html', {'form': form})

@login_required
def create_review(request, reservation_id):
    reservation = Reservation.objects.get(id=reservation_id, user=request.user)
    
    if reservation.status != 'completed':
        messages.error(request, 'Отзыв можно оставить только после посещения ресторана')
        return redirect('profile')
    
    if hasattr(reservation, 'review'):
        messages.error(request, 'Вы уже оставили отзыв на это бронирование')
        return redirect('profile')
    
    if request.method == 'POST':
        form = ReviewForm(request.POST)
        if form.is_valid():
            review = form.save(commit=False)
            review.reservation = reservation
            review.save()
            messages.success(request, 'Спасибо за ваш отзыв!')
            return redirect('profile')
    else:
        form = ReviewForm()
    
    return render(request, 'main/review.html', {
        'form': form,
        'reservation': reservation
    })