from django.urls import path
from django.views.generic import RedirectView
from . import views

urlpatterns = [
    path('', RedirectView.as_view(pattern_name='login'), name='home'),  # Перенаправление с корня
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.profile_view, name='profile'),
    path('reservation/', views.create_reservation, name='create_reservation'),
    path('review/<int:reservation_id>/', views.create_review, name='create_review'),
]